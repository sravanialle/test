 - Assuming Mysql is installed and running
 - Run all the sql queries listed in MySQl DB Scripts.txt file 
 - Successful execution of above statment should result withe database create as "adstest" and 2 table       Author , Book with sample data inserted. 
 - Sending the zipfile of "testspringboot' with pom included.
 - unzip the project in folder and go to the roor directory of application and enter below command
 - can run application in one of the 2 ways 
   1 mvn spring-boot:run
   2 cd "porject location folder"
     mvn clean package 
     java -jar target/jarname.jar i.e, java -jar target/testspringboot-0.0.1-SNAPSHOT.jar
   
    This will make the application up and running.
    Please provide below url in the browser 	     
    "http://localhost:8080/"
    This will give the running application.

   Below are the functionalities implemented in the application.
   1.screen to create a new book
   	a.pre-existing author names populated in dropdown.(created via sql scripts)
	b.Title field , accepts up to 120 characters max, will not acept emojis,but will accept accents.
        test String for emojis : A string ??with a \uD83D\uDC66\uD83C\uDFFFfew ??emojis!=== Error shown : "Error while creating Book: Invalid title entered"
   2.screen lists all the avaiable books(created test data via sql scripts)
   3. For each book/record button to delete respective book.
   4. Integrated Jasper reports to generate barcode with isbncode, title and author details. Sample   	      report  "report.jrxml" is attached with the ADSTEST 	zipfolder.
   5. Provided button for each book "Pdf Report" , generating jasper report in pdf format with given specifications.
	
	

